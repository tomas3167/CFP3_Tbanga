from django.shortcuts import render, redirect
from .models import Productos
 
# Create your views here.

# LOGICA de mi aplicacion
def listar_productos(request): # -- El parametro que siempre tiene que estar como minimo, es el request (la peticion que viene desde la base de datos)
    productos = Productos.objects.all() # -- esto es lo mismo que hacer SELECT FROM etc. en SQL
    # Tengo que retornar los datos de productos en un archivo html para que se vean
    return render(request, 'productos.html', {'productos': productos}) # 'productos.html' es donde van a renderizarse esos datos, y lo otro es un diccionario con la variable que se va a renderizar {'donde esta la variable': la variable}

def crear_producto(request):
    nombre = request.POST["nombre"]
    descripcion = request.POST["descripcion"]
    precio = request.POST["precio"]
    stock = request.POST["stock"]
    producto = Productos(nombre=nombre, descripcion=descripcion, precio=precio, stock=stock)
    producto.save()
    return redirect('/inventario') # redirect es para que nos redireccione a una url

def editar_producto(request, id):
    producto = Productos.objects.get(id=id) # get es obtener
    return render(request, 'editar_producto.html', {'producto' : producto})

def actualizar_producto(request, id):
    producto = Productos.objects.get(id=id)
    nombre = request.POST["nombre"]
    descripcion = request.POST["descripcion"]
    precio = request.POST["precio"]
    stock = request.POST["stock"]
    producto.nombre = nombre
    producto.descripcion = descripcion
    producto.precio = precio
    producto.stock = stock
    producto.save()
    return redirect('/inventario')
