# Creamos urls.py adentro de la aplicacion para trabajar adentro de ella directamente, no desde el core
# las urls generales las ponemos en el otro urls.py

from django.urls import path
from .views import *

urlpatterns = [
    path('', listar_productos, name='listado_productos'), # el 1er parametro es la ruta, el 2do es la funcion que hay que importar de views (la parte logica), y el 3ro no es obligatorio pero sirve como alias a la funcion por si es muy largo el nombre
    path('CrearProductoNuevo/', crear_producto, name='crear_producto'),
    path('editar/<id>', editar_producto, name='editar_producto'),
    path('actualizar_producto/<id>', actualizar_producto, name='actualizar_producto')

]