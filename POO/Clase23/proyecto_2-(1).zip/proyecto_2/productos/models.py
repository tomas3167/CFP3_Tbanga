from django.db import models
# Create your models here.

# Creo mi entidad productos
class Productos(models.Model):
    # ----- Es lo mismo que el def __init__ , cuando usamos models, python ya entiende que son variables
    nombre = models.CharField(max_length=255)
    descripcion = models.CharField(max_length=255)
    precio = models.DecimalField(max_digits=10, decimal_places=2)
    stock = models.IntegerField()

    def __str__(self):
        return self.nombre

    # -- IMPORTANTE --
  # ----- cuando creo una entidad le tengo que decir a django que la quiero en la aplicacion, eso se hace con el manage.py.
  # En el cmd donde esta el proyecto ponemos "python manage.py makemigrations". Al principio sale "No changes detected", para esto hay que avisarle a django que hicimos la aplicacion
  # vamos a setting.py en 'core', y en INSTALLED_APPS agregamos entre '' el nombre de la aplicacion (la carpeta)
 # -- todos los comandos se hacen con el manage.py desde el cmd, siempre es "python manage.py 'comando' "
# python manage.py makemigrations: busca si hay nuevos cambios
# python manage.py migrate: guarda esos cambios
# como el git push y git commit

# python manage.py runserver para iniciar el server, luego entramos a la url del server, ej: http://127.0.0.1:8000/ y le agregamos admin despues de la /.
# para entrar como admin hay que crear un usuario y contraseña. ponemos python manage.py createsuperuser y lo creamos. si le damos enter sin poner nada en el mail no lo pide despues
# para cambiar el lenguaje vamos a settings.py en LANGUAGE_CODE = 'es-arg'