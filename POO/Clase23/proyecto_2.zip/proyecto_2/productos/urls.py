# Creamos urls.py adentro de la aplicacion para trabajar adentro de ella directamente, no desde el core
# las urls generales las ponemos en el otro urls.py

from django.urls import path
from .views import *

urlpatterns = [
    path('', listar_productos, name='listado_productos'),
    
]