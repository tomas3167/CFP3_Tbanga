from django.contrib import admin
from .models import Productos

admin.site.register(Productos)

# Register your models here.
