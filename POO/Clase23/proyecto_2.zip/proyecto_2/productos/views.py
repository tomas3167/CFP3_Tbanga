from django.shortcuts import render
from .models import Productos

# LOGICA de mi aplicacion
def listar_productos(request): # -- El parametro que siempre tiene que estar como minimo, es el request (la peticion que viene desde la base de datos)
    productos = Productos.objects.all() # -- esto es lo mismo que hacer SELECT FROM etc. en SQL
    return render(request, 'productos.html', {'productos': productos}) # 'productos.html' es donde van a renderizarse esos datos, y lo otro es un diccionario con la variable que se va a renderizar {'donde esta la variable': la variable}

# Create your views here.
